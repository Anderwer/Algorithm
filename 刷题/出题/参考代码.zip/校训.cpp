#include <bits/stdc++.h>
using i64 = long long;
using namespace std;

void solve()
{
    int x;
    cin >> x;
    if(x == 1) cout << "江西理工大学";
    else if(x == 2) cout << "志存高远责任为先";
    else cout << "我们从这里启航";
}

int main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    solve();
    return 0;
}
